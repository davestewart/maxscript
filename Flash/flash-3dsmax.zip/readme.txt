
NOTE
====================================================================================================================

	These demos are from 2002!
	
	* The character ui demo won't load the max model unless you are running an old version
	  of max with the attachment2 controller
	* The flash UI component will not run in later versions of 3dsmax due to the active-x control code
	* If editing the .fla files, Flash 5 and above will convert the Flash 4 code to something that is particularly ugly!



INSTALLATION
====================================================================================================================

	IMPORTANT: To get the swf files showing, you will need to edit the path to the SWF in each of the .ms files.



FUTURE DEVELOPMENT
====================================================================================================================

	If you want to get into Flash / 3dsmax communication, look into ExternalInterface, and 
	start writing your code using proper AS2 / AS3 classes.
	
	Have fun :)