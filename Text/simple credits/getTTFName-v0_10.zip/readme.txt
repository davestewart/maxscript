Zip File Name:		getTTFName-v0_10.zip
Script Name:		"Get True Type Font Name"
Version:		v0.10
Creation Date:		11Aug2001
Status:			Beta (1st release!)
Required Extensions:	None
Encrypted:		n
Language:		English
MAX Build:		r4.20
Author:			swami*, a.k.a. "codeWarrior()", swami@cfl.rr.com
Script Description:	To get common names of system ttf fonts.

Excerpt from script header...
--*****************************************************
--
--  ***************************************************
--  ***       FOR NON-COMMERCIAL USE ONLY!          ***
--  *** Contact the author for licensing agreement  ***
--  ***            or custom scripting              ***
--  ***       copyright 2001 SWAMANIMATIONS!        ***
--  ***************************************************
--
--*****************************************************
-- INSTALLATION:
--
-- Required Extensions  :
-- Required Scripts     :
-- Required Files       :ttfname.exe
-- Optional Files       :ttfname-v1_0.zip (source & exe)
--                      :TableDirectory&NameIDsExplained-010809-02.zip
--
--    - Put script anywhere.
--    - Put 'ttfname.exe' in max ..\scripts.
--*****************************************************
-- PURPOSE:
--    - To get common names of system ttf fonts.
--*****************************************************
-- USAGE:
--    - See end of script for examples...
--*****************************************************
-- COMMENTS:
--    - This is a WIP.
--    - There has been minimal testing. More is required...
--    - There is minimal error checking/handling.
--    - The script is NOT optimized.
--
--    - Dave Stewart <3dsmax@davestewart.co.uk> wrote:
--    - "
--    - Is it possible to get a list of installed fonts as an array to place in a dropdownlist box?
--    - "
--
--    - This script is a LIMITED solution.  Future versions will improve upon it...
--
--    - Overview of operation:
--        - ttf font names are gotten via a call to 'ttfname.exe' using 'DOSCommand'
--          (this leads to limitations which will be discussed, later...).
--          This executable runs in console mode in a DOSPrompt window.  The source code is in C++.
--        - The ttf font filenames are put into an array (via MXS).
--        - ttfname is called in a loop: once for each file.
--        - ttfname ATTEMPTS to read the Name Table data in the ttf.
--        - The results are output to the console by ttfname.
--        - This is piped to a temp file (c:\ttfnameTMP.txt) by MXS.
--        - According to the ttf spec., line 5 is the font common name.  This is the name which appears
--          in a max text object's dropdown list and the one required by the '.font' property in MXS.
--        - This line is put into a data structure which also contains the associated filename.
--        - The result is an array of data structures from which the names can be pulled (and sorted).
--          This has been automated via a call to 'getTTFNameStrs()'.
--        - Several usage examples are provided at the end of the script.
--
--    - Limitations:
--        - Each call to ttfname pops up a DOSPrompt window! That's a lot o windows considering the number
--          of fonts in the Windows fonts directory (150 on my system). It works, but it ain't pretty!
--        - ttfname does NOT always find a name table, or errors out in some way, resulting in 'undefined'
--          being assigned to the font name :( My test yielded 110 out of the 150 installed.
--
--    - Future Plans/Fixes...
--       1) The best fix is to realize the ttfname functionality in MXS. Binary read is possible in MXS,
--          and I have been able to identify some matching methods, so hopefully a conversion is possible.
--       2) Another fix is to modify the ttfname code to process an array of files (not just one at a time
--          as it currently does), and to output the results to a data file (instead of to the console).
--          This could then be read by MXS.
--       3) Get the font names from the Registry (don't know if I want to go there!)
--
--        - Solutions 1 and 2 require that I FULLY understand the ttfname code.
--          Time to dig in and learn some C++!...
--
--        - But in the meantime, here's a chunk of code that gets the font names into an array
--          (well, most of 'em)...
--*****************************************************
-- HISTORY:
-- (Legend: M => Major change; m => minor change; B => Bug fix; (i) => info.)
--    - v0.10 (08.11.01):
--        (i) 1st Beta version.
--*****************************************************