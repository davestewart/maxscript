/*  � Clientside Tech and NMG Consulting, LLC  (www.clientsidetech.com)  */
DOMCloner={
  a:"a",
  A:"A",
  i:"INPUT",
  get:function(type){
    type = type.toLowerCase();
    if(this.elements[type] == null){
      this.elements[type] = dh.a(type);
    }
    return this.elements[type].cloneNode(false);
  },
  getN:function(type,id,className,innerHTML){
    type = type.toLowerCase();
    if(this.elements[type] == null){
      this.elements[type] = dh.a(type);
    }
    var elem = this.elements[type].cloneNode(false);
    elem.id = id;
    elem.className = className;
    if(innerHTML!=null)elem.innerHTML = innerHTML;
    return elem;
    },
  getA:function(href,innerHTML,className,id){
    if(this.elements[this.a] == null){
      this.elements[this.a] = dh.a(this.A);
    }
    var elem = this.elements[this.a].cloneNode(false);
    elem.href = href;
    elem.innerHTML = innerHTML;
    elem.className = className;
    elem.id = id;
    return elem;
  },
  getI:function(type,value,className,id){
    type.toLowerCase();
    if(this.elements[type] == null){
      this.elements[type] = dh.a(this.i);
      this.elements[type].type = type;
    }
    var elem = this.elements[type].cloneNode(false);
    elem.id = id;
    elem.name = name;
    elem.className = className;
    elem.value = value;
    return elem;
  },
  elements:NA()
}
dc = DOMCloner;
dc.g = dc.get;
dc.gn = dc.getN
dc.gi = dc.getI;
dc.ga = dc.getA;
