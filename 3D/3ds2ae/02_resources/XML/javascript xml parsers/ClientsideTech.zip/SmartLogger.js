/*  � Clientside Tech and NMG Consulting, LLC  (www.clientsidetech.com)  */
// Requires DatePackage.js,DOMHelper,DOMCloner, CSTUtils
SmartLogger = {
	log:function(x,y){
		 x = this.makeLogItem(x,y,ND());
		 if(this.verifyLogSpan() && this.active){
		 	  if(!this.dumpingSafeLogs) this.dumpSafeLogs();
		    this.writeLog(x);
		    this.logs.push(x);
		    if(x.alert && this.verifyAlert()){
		    	alert(x.message);
		    }
		 }
		 else{
		    this.safeLog(x);
	   }
	},
  verifyLogSpan:function(){
    if(document == null || document.body == null 	) {
    	return false;
    }
		if(dh.b(this.logId) == null){
			this.createLogSpan();
		}
		if(dh.b(this.logId).childNodes.length == 0){
			dh.d(dh.b(this.logId),dc.gn("OL",null,"SmartLoggerList",null));
		}
		return true;
	},
	createLogSpan:function(){
		 dh.d(document.body,dc.gn("SPAN",this.logId,"SmartLogger",null));
		 dh.d(dh.b(this.logId),dc.g("OL"));
	},
	logId:"SmartLoggerSpan",
	safeLogs:NA(),
	logs:NA(),
	makeLogItem:function(x,y,d){
	   return this.isLogItem(x)?x:new this.LogItem("" + x,y,d);
	},
  isLogItem:function(x){
  	  if(typeof x == "object" && x.constructor != null && x.constructor == this.LogItem.prototype.constructor){
         return true;
	    }
			return false;
  },
	writeLog:function(x){
		dh.d(dh.b(this.logId).childNodes[0],this.makeLogEntry(x));
	},
	safeLog:function(x){
		x.message = "SAFELOG:" + x.message;
		this.safeLogs.push(x);
	},
	dumpSafeLogs:function(){
		this.dumpingSafeLogs = true;
		for(var i=0;i<this.safeLogs.length;i++){
		  this.log(this.safeLogs[i]);
		}
		this.safeLogs = NA();
    this.dumpingSafeLogs = false;
	},
	makeLogEntry:function(x){
		var s = dc.g("SPAN");
		var s1 = dc.g("SPAN");
		s.innerHTML = " &nbsp;-- " + x.message;
		s1.innerHTML = x.timestamp.getTimeStamp();
		SC(s1,"SmartLoggerItemLabel");
		SC(s,"SmartLoggerItem");
		return dh.f(dc.g("LI"),s1,s,true);
	},
	active:true,
	verifyAlert:function(){
		return alert.prototype == null;
	},
	LogItem:function(x,y,d){
		this.message = x;
		this.alert = y==null?false:y;
		this.timestamp = d;
	}
}

sl = SmartLogger;
sl.log("SmartLogger.js loaded");

