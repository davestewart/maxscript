/**********************************************************************************************/
***   Readme for SmartTable Basic version
***   � 2004 - 2005 Clientside Tech and NMG Consulting, LLC (www.clientsidetech.com)
***   This copyright notice MUST remain in place per the Terms and Conditions found at http://www.clientsidetech.com/Terms.php
***   By using this product you agree that you have read and agreed with the terms.
/**********************************************************************************************/


This Readme file applies to the basic version of SmartTables.  
The full version offers an XML config file, search capability, edit mode,
and serializing.


HOW TO USE SMART TABLES

See the full API documentation at http://www.clientsidetech.com/SmartTablesAPI.php

Part I.   The Basics
--------------------
Let's get up and running ASAP.  Here's how to set up a bare bones, basic features SmartTable.

    SETUP:

    First, your HTML page must include the SmartTableObject.js script.
    If you are not using the standalone version, you must also include the following scripts,
    in order:  CSTUtils.js, DOMHelper.js, DOMCloner.js, DatePackage.js, XMLHelper.js
    See http://www.clientsidetech.com/Downloads.php or a list of each component and their
    dependencies.

    Include a Link reference or inline copy of your style sheet.
    <LINK href="SmartTables.css" type=text/css rel=stylesheet>

    Your html should have a <TABLE> object ready to be used by the SmartTable javascript.
    If there is no HTML table ready, the SmartTable object will create one for itself and append
    it to the bottom of the page.  However, there is no way to set CELLPADDING, CELLSPACING properties
    on a table from a style sheet, so if you don't have your own table tag with those properties set,
    the defaults will be in place.

    PROPERTIES:

    If you don't create your own SmartTableParams object, the default will be used.
    See the API for the constructor, but the SmartTableParams object is where you establish
    the following properties:

    classNameRoot (discussed in STYLE section below)
    sortable (applies to all columns):  default true
    searchable (applies to all columns):  default true
    paginate-able(is that a word?):  default true:
    rows per pagination:   default 20
    pagination links delimiter:  default "|"
    active: default true
    deserialization delimiter:  default ","
    links per group of pagination links:  default 15
    editable (applies to all columns):default false;
    serializing changes only option:  default false, entire data set is returned from serialize() method

    Create your own with some different values.
    example: p = new SmartTableParams(true,false,true,15,"-",true,null,15,false,false);
    This table will have no searching, and some different pagination behaviour.
    Again, view the SmartTableParams API for more about this object and its contructor.

    You can apply column level controls to sort, and style if you desire.
    To set these properties for a given column only, use these setter methods.

    setColumnStyle(style,column)
    setSortable(true/false,column)

    See API for further explanation of these methods and see "Edit Mode" section below for more on that.


    INSTANTIATION:

    Create the data in javascript, either a 2d array or a delimited string.
    Two examples below:
    var count = 0;
    var dataArray = new Array();
    var dataArray[count++] = ["valueA",valueB,"valueC"]
    var dataArray[count++] = ["valueA",valueB,"valueC"]
    var dataArray[count++] = ["valueA",valueB,"valueC"]
    var dataArray[count++] = ["valueA",valueB,"valueC"]
		.... and so on

		or

		var dataString = "value1,value2,value3,value4,value5......"

		So how does the SmartTable know how to deserialize properly?  This brings us to the
		next part of instatiation, the columns.

		You need an array of strings representing each column name, from left to right = 0  to x.
		For example:  mycols = ["Name","Date","Email","Job Title"]
		The deserializer uses the length of the column names array to break up the CSV into rows.

    Now, to create the SmartTable is easy.  Just pass it the params object, the data, the columns,
    and the id of the HTML table tag.

    example:  var myTable = new SmartTable("smartTableHTMLID",params,data,columns)

    DONE!

    Oh one last thing.  After the document has loaded you need to
    initiate the generating of all the SmartTables on that page with SmartTables.init().
    The SmartTables object is a manager object that holds the collection of all SmartTables,
    initializes them upon command.

    That's it!  You've got a SmartTable now.


Part 2. CUSTOM RENDERING

    The default behaviour of the SmartTable is to render each piece of data as plain text
    with the table cells. But sometimes you want to do more.  You want to make the data
    into an email link, or attach an onclick event to it, or make it into a checkbox.

    You must create your own javascript function that conforms to the SmartTable renderer
    contract.  The contract requires a signature with  four arguments:
    1.  Array :(the row of data)
    2.  number :(the column index)
    3.  TD Dom object:  the table cell, which will be the return value
    4.  number :  The index of the row within the data set

    The renderer is also obliged to return the td argument that was passed to it.

    Once you have created a function that takes those four arguments and creates
    whatever kind of content you want for the TD object, you must add the function
    to the SmartTable and tell it which column will use that renderer.  The method is simple.

    example:  mySmartTableInstance.setRenderer(2,myRendererFunction);

    Try http://www.clientsidetech.com/SmartTablesFAQ.php for some examples


Part 3. STYLES

    SmartTables give you comprehensive style controls.  If you view the default style sheet
    that comes with the download, you'll see that every classname starts with "smt".  This
    is the style root that is part of the SmartTableParams object.  The SmartTable knows
    to  prepend this root to every classname for objects it is creating on the fly.

    You may customize styles by either modifying the default style sheet itself, or
    you can create your own with a new rootname and use that instead.  If you do that,
    you must set the classNameRoot property on SmartTableParams to the root name you chose.

    The styles you have access to and what they modify :

    - the HTML Table elements -

    TABLE.smtTable{}   the HTML table
    TR.smtRowOdd{}   all odd rows in the table.
    TR.smtRowEven{}   all even rows in the table.
    TD.smtRowOdd{}   all table cells in  odd rows in the table.
    TD.smtRowEven{}   all table cells in even rows in the table.


    - the column headers -

    TR.smtHeader {}   the row with the column headers
    TD.smtHeader {}   the cells in the header row
    A.smtHeader  {}   the header name when it is a link for sorting
    A.smtHeader:visisted{}
    A.smtHeader:hover{}
		TR.smtButtons{}     Row holding the "search" button and search status message
		TD.smtButtons{}     Cell in the buttons row
		.smtSearchStatusDisplay{} The span holding the search status message

    - Footer elements -

		TR.smtFooter{}   The bottom row of the table, holding the pagination links cell
		TD.smtFooter{}   The cell in the footer row, holding the pagination links
		A.smtPaginationLink {}  if I have to explain what this does....
		A.smtPaginationLink:visited {}
		A.smtPaginationLink:hover {}
		SPAN.smtPaginationDelimiter {}  Applies to every pagination delimiter

		.smtTotalRowsDisplay{} Applies to the SPAN that holds the message displaying total rows in the table

    - Search Elements -

		A.smtSearchLink{}  Applies to the search button
		A.smtSearchLink:visited{}
		A.smtSearchLink:hover{}


		Div.smtSearchDiv{}  The main container of the search options content
		Div.smtSearchDivHeader{} the top portion of the search options content
		Div.searchContentDiv{} the portion that holds the form fields in the search area
		Div.centeringDiv{}  A wrapper div to center the whole content of the search panel
    .smtSearchOptionsErrors{} the display area at the bottom of the search panel when user enters invalid search parameters


Part 4.  Support

   A FAQ is available at http://www.clientsidetech.com/SmartTablesFAQ.php
   The full API documentation is available at http://www.clientsidetech.com/SmartTablesAPI.php

   You can email me at support@clientsidetech.com

   Feel free to contact me for questions about implementation, feature requests,
   and to report any bugs.  Thanks.


