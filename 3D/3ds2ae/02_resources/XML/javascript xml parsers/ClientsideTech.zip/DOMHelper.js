/*  � Clientside Tech and NMG Consulting, LLC  (www.clientsidetech.com)  */
DOMHelper = {
    DCE:function(x){
		    return document.createElement(x)
	  },
    DGE:function(x){
		    return document.getElementById(x)
	  },
	  DGBN:function(x){
	      return document.getElementsByName(x)
	  },
	  AC:function(a,b,c){
  	    a.appendChild(b);
  	    if(c != null && c == true){
  		      return a
  	    }
    },
    ACL:function(){
      var a = arguments;
      var m =0, l=1;
      bReturn = false;
      var limit = a.length;
      if(typeof a[a.length-1] == "boolean"){
          bReturn = a[a.length-1];
          limit = a.length -1;
      }
      while(l != limit){
   	      a[m].appendChild(a[l]);
   	      l++;m++;
      }
      if(bReturn){
          return a[0];
      }
    },
    ACN:function(){
      var a = arguments;
      var m =0, l=1;
      bReturn = false;
      var limit = a.length;
      if(typeof a[a.length-1] == "boolean"){
          bReturn = a[a.length-1];
          limit = a.length -1;
      }
      while(l != limit){
   	      a[m].appendChild(a[l]);
   	      l++;
      }
      if(bReturn){
         return a[0];
      }
   },
   RC:function(a,b,c){
  	  a.replaceChild(b,c)
   },
   SN:function(a,b){
  	  a.parentNode.replaceChild(b,a)
   },
   GOBS:function(a){
   	return typeof a == "string"?dh.b(a):a;
   }

}


dh = DOMHelper;
dh.a = dh.DCE;
dh.b = dh.DGE;
dh.c = dh.DGBN;
dh.d = dh.AC;
dh.e = dh.ACL;
dh.f = dh.ACN;
dh.g = dh.RC;
dh.h = dh.SN;
dh.i = dh.GOBS;
