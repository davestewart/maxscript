/*  � Clientside Tech and NMG Consulting, LLC  (www.clientsidetech.com)  */
SelectMenuHelper = {
	GSV:function(a){
		a = dh.GOBS(a);
		return a.options[a.options.selectedIndex].value;
	},
	GSI:function(a){
		return dh.GOBS(a).options.selectedIndex;
	},
	MSO:function(a,b,c){
		var s1 = dh.GOBS(a);
		var s2 = dh.GOBS(b);
		var o = s1.options[sh.GSI(s1)];
		sh.AO(s2,o.text,o.value);
		if(c == null || !c ) sh.RO(s1,sh.GSI(s1));
	},
	CSO:function(a,b){
		sh.MSO(a,b,true);
	},
	GOL:function(a){
		return dh.GOBS(a).options.length;
	},
	AO:function(a,b,c){
		  dh.GOBS(a).options[sh.GOL(a)] = sh.NO(b,c);
	},
	RO:function(a,b){
		dh.GOBS(a).options[b] = null;
	},
	NO:function(a,b){
	   return new Option(a,b);
	},
	GSO:function(a){
     return dh.GOBS(a).options[sh.GSI(a)];
    },
	ROL:function(a,b){
		 a = dh.GOBS(a);
	   if(typeof b[0] == "string"){
	   	 b = nvpc.convertStringArray(b);
	   }
	   for(var i=0;i<b.length;i++){
	   	 a.options[i] = sh.NO(b[i].name,b[i].value);
	   }
	   if(a.options.length > b.length){
	      var l = b.length-1;
				var c = a.options.length-1;
	   	  while(c != l){
	   	    a.options[c--] = null;
	   	  }
	   }
	},
	MU:function(a){
		a = dh.GOBS(a);
		var i = sh.GSI(a);
		if(i > 0){
 		    var o = sh.GSO(a);
		    var o2 = a.options[i-1];

		    var t = sh.NO(o.text,o.value);
			  var t2 = sh.NO(o2.text,o2.value);
			  a.options[i-1] = t;
			  a.options[i-1].selected = true;
			  a.options[i] = t2;
		}
	},

	MD:function(a){
		a = dh.GOBS(a);
		var i = sh.GSI(a);
		if(i < a.options.length -1 ){
 		    var o = sh.GSO(a);
		    var o2 = a.options[i+1];
		    var t = sh.NO(o.text,o.value);
			  var t2 = sh.NO(o2.text,o2.value);
			  a.options[i+1] = t;
			  a.options[i+1].selected = true;
			  a.options[i] = t2;
		}
	}
}
sh = SelectMenuHelper;
//sh.a = sh.GSV;

/*
GSV = get selected value
GSI = get selected index
MSO = move selected options
CSO = copy selected options
AO = add Option
RO = remove Option by index
SO = sort options;
NO = new Option
GSO get selected option object
GOL = getOptions legnth
ROL = Replace options list
MU = move up
MD = move down
*/
/*
sort(bText/bValue)
Set selected index to...
*/