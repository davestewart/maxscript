/**********************************************************************************************/
***   Readme for SmartTable
***   � 2004 - 2005 NMG Consulting, LLC (www.clientsidetech.com)
***   This copyright notice MUST remain in place per the Terms and Conditions found at http://www.clientsidetech.com/Terms.php
***   By using this product you agree that you have read and agreed with the terms.
/**********************************************************************************************/


This Readme file applies to the full version of SmartTables.  See
the basic version Readme for information about that product which offers
fewer features but is a much smaller download.


HOW TO USE SMART TABLES

See the full API documentation at http://www.clientsidetech.com/SmartTablesAPI.php

Part I.   The Basics
--------------------
Let's get up and running ASAP.  Here's how to set up a bare bones, basic features SmartTable.

    SETUP:

    First, your HTML page must include the SmartTableObject.js script.
    If you are not using the standalone version, you must also include the following scripts,
    in order:  CSTUtils.js, DOMHelper.js, DOMCloner.js, DatePackage.js, XMLHelper.js
    See http://www.clientsidetech.com/Downloads.php or a list of each component and their
    dependencies.

    Include a Link reference or inline copy of your style sheet.
    <LINK href="SmartTables.css" type=text/css rel=stylesheet>

    Your html should have a <TABLE> object ready to be used by the SmartTable javascript.
    If there is no HTML table ready, the SmartTable object will create one for itself and append
    it to the bottom of the page.  However, there is no way to set CELLPADDING, CELLSPACING properties
    on a table from a style sheet, so if you don't have your own table tag with those properties set,
    the defaults will be in place.

    PROPERTIES:

    If you don't create your own SmartTableParams object, the default will be used.
    See the API for the constructor, but the SmartTableParams object is where you establish
    the following properties:

    classNameRoot (discussed in STYLE section below)
    sortable (applies to all columns):  default true
    searchable (applies to all columns):  default true
    paginate-able(is that a word?):  default true:
    rows per pagination:   default 20
    pagination links delimiter:  default "|"
    active: default true
    deserialization delimiter:  default ","
    links per group of pagination links:  default 15
    editable (applies to all columns):default false;
    serializing changes only option:  default false, entire data set is returned from serialize() method

    Create your own with some different values.
    example: p = new SmartTableParams(true,false,true,15,"-",true,null,15,false,false);
    This table will have no searching, and some different pagination behaviour.
    Again, view the SmartTableParams API for more about this object and its contructor.

    You can apply column level controls to search, edit, sort, and style if you desire.
    To set these properties for a given column only, use these setter methods.

    setColumnStyle(style,column)
    setEditMode(mode,column)  - NOTE:  if mode is not equal to "text" or "select", column is not editable
    setSearchable(true/false,column)
    setSortable(true/false,column)

    See API for further explanation of these methods and see "Edit Mode" section below for more on that.


    INSTANTIATION:

    Create the data in javascript, either a 2d array or a delimited string.
    Two examples below:
    var count = 0;
    var dataArray = new Array();
    var dataArray[count++] = ["valueA",valueB,"valueC"]
    var dataArray[count++] = ["valueA",valueB,"valueC"]
    var dataArray[count++] = ["valueA",valueB,"valueC"]
    var dataArray[count++] = ["valueA",valueB,"valueC"]
		.... and so on

		or

		var dataString = "value1,value2,value3,value4,value5......"

		So how does the SmartTable know how to deserialize properly?  This brings us to the
		next part of instatiation, the columns.

		You need an array of strings representing each column name, from left to right = 0  to x.
		For example:  mycols = ["Name","Date","Email","Job Title"]
		The deserializer uses the length of the column names array to break up the CSV into rows.

    Now, to create the SmartTable is easy.  Just pass it the params object, the data, the columns,
    and the id of the HTML table tag.

    example:  var myTable = new SmartTable("smartTableHTMLID",params,data,columns)

    DONE!

    Oh one last thing.  After the document has loaded you need to
    initiate the generating of all the SmartTables on that page with SmartTables.init().
    The SmartTables object is a manager object that holds the collection of all SmartTables,
    initializes them upon command, and also facilitates some XML configuration functionality discussed
    below.

    That's it!  You've got a SmartTable now.

Part 2.  XML CONFIGURATION:


    Go to http://www.clientsidetech.com/SmartTablesXML.php for a handy form that will generate
    the config xml for you.  Also, the download package came with an example XML config file, which you can use
    as a template.


    SmartTables can be initiated with a different constructor, one that takes an XML reference
    as an argument.  If the XML conforms to the proper schema, the script will retrieve
    all the properties from the XML.  The constructor is a method on the SmartTables object.

    Creating SmartTables becomes even easier when using XML config files:

    example:
         var xml = "/xmlsources/smarttableXMLConfig.xml";
         var mytable = SmartTables.createFromXML(xml,id,cols,data,params,metadata);


    All the parameters except xml are optional.  Each one has a schema element
    that can be populated in the XML, or you can pass it along explicitly to the constructor.

    The XML config feature works equally well for both IE and mozilla based browsers.


Part 3. CUSTOM RENDERING

    The default behaviour of the SmartTable is to render each piece of data as plain text
    with the table cells. But sometimes you want to do more.  You want to make the data
    into an email link, or attach an onclick event to it, or make it into a checkbox.

    You must create your own javascript function that conforms to the SmartTable renderer
    contract.  The contract requires a signature with  four arguments:
    1.  Array :(the row of data)
    2.  number :(the column index)
    3.  TD Dom object:  the table cell, which will be the return value
    4.  number :  The index of the row within the data set

    The renderer is also obliged to return the td argument that was passed to it.

    Once you have created a function that takes those four arguments and creates
    whatever kind of content you want for the TD object, you must add the function
    to the SmartTable and tell it which column will use that renderer.  The method is simple.

    example:  mySmartTableInstance.setRenderer(myRendererFunction,2);

    Try http://www.clientsidetech.com/SmartTablesFAQ.php for some examples


Part 4. STYLES

    SmartTables give you comprehensive style controls.  If you view the default style sheet
    that comes with the download, you'll see that every classname starts with "smt".  This
    is the style root that is part of the SmartTableParams object.  The SmartTable knows
    to  prepend this root to every classname for objects it is creating on the fly.

    You may customize styles by either modifying the default style sheet itself, or
    you can create your own with a new rootname and use that instead.  If you do that,
    you must set the classNameRoot property on SmartTableParams to the root name you chose.

    The styles you have access to and what they modify :

    - the HTML Table elements -

    TABLE.smtTable{}   the HTML table
    TR.smtRowOdd{}   all odd rows in the table.
    TR.smtRowEven{}   all even rows in the table.
    TD.smtRowOdd{}   all table cells in  odd rows in the table.
    TD.smtRowEven{}   all table cells in even rows in the table.


    - the column headers -

    TR.smtHeader {}   the row with the column headers
    TD.smtHeader {}   the cells in the header row
    A.smtHeader  {}   the header name when it is a link for sorting
    A.smtHeader:visisted{}
    A.smtHeader:hover{}
		TR.smtButtons{}     Row holding the "search" button and search status message
		TD.smtButtons{}     Cell in the buttons row
		.smtSearchStatusDisplay{} The span holding the search status message

    - Footer elements -

		TR.smtFooter{}   The bottom row of the table, holding the pagination links cell
		TD.smtFooter{}   The cell in the footer row, holding the pagination links
		A.smtPaginationLink {}  if I have to explain what this does....
		A.smtPaginationLink:visited {}
		A.smtPaginationLink:hover {}
		SPAN.smtPaginationDelimiter {}  Applies to every pagination delimiter

		.smtTotalRowsDisplay{} Applies to the SPAN that holds the message displaying total rows in the table

    - Search Elements -

		A.smtSearchLink{}  Applies to the search button
		A.smtSearchLink:visited{}
		A.smtSearchLink:hover{}


		Div.smtSearchDiv{}  The main container of the search options content
		Div.smtSearchDivHeader{} the top portion of the search options content
		Div.searchContentDiv{} the portion that holds the form fields in the search area
		Div.centeringDiv{}  A wrapper div to center the whole content of the search panel
    .smtSearchOptionsErrors{} the display area at the bottom of the search panel when user enters invalid search parameters

    - Editable Elements -
    .smtEditableSpanMouseover {} the mouseover class to be used when you mouse over an editable cell
    .smtEditableText{}  applied to the text field element when editing
    .smtEditableSelect{}  applied to the select menu element when editing


Part 5. EDIT MODE

    If you want to let users edit values directly with a free form text field, it's easy.
    Just set the editMode on that column to "text".

    example:  mySmartTableInstance.setEditMode('text',2);

    The text values in the third column will turn into text fields for editing when the user
    clicks on it.

    If you want to constrain the user's edits with a select menu, you'll need to set the edit
    mode to "select" and provide a list of options.

    To use a list of options where the text and value are all the same, just create an array
    of strings.  To use a list of options where the text and value are different, you'll
    need to create an array of NameValuePairs.  (See the Utils API at http://www.clientsidetech.com/Utils.php).
    Then you just set the options on the smart table with a setter method and that's it!


    example:
         var theOptions = ["optionA","optionB","optionC","optionD"];
         mySmartTableInstance.setEditableSelectValues(theOptions,2);

				 Or....

				 var theOptions = new Array();
				 theOptions[0] = new NameValuePair("optionA",0);
				 theOptions[1] = new NameValuePair("optionB",1);
				 theOptions[2] = new NameValuePair("optionC",2);
				 theOptions[3] = new NameValuePair("optionD",3);
				 theOptions[4] = new NameValuePair("optionE",4);
				 theOptions[5] = new NameValuePair("optionF",5);
         mySmartTableInstance.setEditableSelectValues(theOptions,2);

    Column 3 will now present a select menu when the user clicks on a cell.

		If you want to actually DO something with the data changes, you'll probably
		want to submit them.  To get the current state of the table data, use the
		serialize() method. See the SmartTables API for further info on this method.

		It will either give you the entire data set, or just the rows that have been modified,
		depending on your SmartTableParams values.  Once you have the serialize() results,
		you can put that value in to a form element and submit to your processor.

Part 6.  Support

   A FAQ is available at http://www.clientsidetech.com/SmartTablesFAQ.php
   The full API documentation is available at http://www.clientsidetech.com/SmartTablesAPI.php
   A nifty form that generates the XML config file is avaialable at http://www.clientsidetech.com/SmartTablesXML.php

   You can email me at support@clientsidetech.com

   Feel free to contact me for questions about implementation, feature requests,
   and to report any bugs.  Thanks.


