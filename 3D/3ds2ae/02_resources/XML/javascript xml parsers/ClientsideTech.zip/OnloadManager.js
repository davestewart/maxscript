/*  � Clientside Tech and NMG Consulting, LLC  (www.clientsidetech.com)  */
OnloadManager = {
	active:true,
	onloads:NA(),
	add:function(x){
		this.onloads.push(x);
	},
	init:function(){
		if(document.body == null){
			sl.log(" om.init():   setting init() timeout for another half second");
			window.setTimeout("om.init()",500);
		}
	  else if(this.active){
	  	sl.log(" body loaded, calling om.fire()");
	  	this.fire();
	  }
	},
	fire:function(){
    if(this.active){
    	sl.log(" firing " + this.onloads.length);
			for(var i=0;i<this.onloads.length;i++){
			   if(typeof this.onloads[i] == "string"){eval(this.onloads[i])}
         else{this.onloads[i]()}
      }
    }
    else{
       sl.log("om.fire() :  manager not active");
    }
	}
}
om = OnloadManager;
om.init();
om.add("sl.log('testing eval')");
om.add(onloadtest);
function onloadtest(){
  sl.log("this is the onload FUNCTION test");
}