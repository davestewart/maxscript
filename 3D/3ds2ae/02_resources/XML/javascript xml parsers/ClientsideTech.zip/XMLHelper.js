/*  � Clientside Tech and NMG Consulting, LLC  (www.clientsidetech.com)  */
XMLHelper ={
    getXMLDomObject:function(src){
        var xmlDoc = null;
        if(window.ActiveXObject != null){
            return this.getActiveXDom(src);
        }
        else if (document.implementation != null && document.implementation.createDocument != null){
            return this.getW3CDom(src);
        }
    },
    getActiveXDom:function(src){
        // xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
        xmlDoc = new ActiveXObject("Msxml.DOMDocument");
        xmlDoc.async = false;
        if(src.indexOf("<") == 0){
            xmlDoc.loadXML(src);
        }
        else{
            xmlDoc.load(src);
        }
        while(xmlDoc.readyState != 4) {};
        return xmlDoc;
    },
    getW3CDom:function(src){
        xmlDoc=document.implementation.createDocument("", "doc", null)
        xmlDoc.load(src);
        return xmlDoc;
    },
    removeWhiteSpaceNodes:function(xml){
      var notWhitespace = /\S/
      if(xml.childNodes && xml.childNodes.length > 0){
        for(var i=0;i<xml.childNodes.length;i++){
          if (xml.childNodes[i].nodeType == 3 && !notWhitespace.test(xml.childNodes[i].nodeValue)) {
		    xml.removeChild(xml.childNodes[i])
		    i--
	      }
	      else{
	        this.removeWhiteSpaceNodes(xml.childNodes[i]);
	      }
        }
     }
   },
   getSingleValueFromXML:function(doc,val){
       var x = doc.getElementsByTagName(val);
       if(x != null && x.length > 0){
           return x[0].firstChild.nodeValue;
       }
       else{
           return null;
       }
   },
   getUniqueElement:function(doc,val){
       var x = doc.getElementsByTagName(val);
       if(x != null && x.length > 0){
           return x[0].firstChild;
       }
       else{
           return null;
       }
   },
   gtn:function(doc,name){
     return doc.getElementsByTagName(name);
   }
}
xh = XMLHelper;
xh.gsv = xh.getSingleValueFromXML;
xh.gue = xh.getUniqueElement;
sl.log("XMLHelper.js:   LOADED");




