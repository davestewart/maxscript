/*  � Clientside Tech and NMG Consulting, LLC  (www.clientsidetech.com)  */
function NameValuePair(a,b){
  this.name = a;
  this.value = b;
}
function NameValuePairCollection(pairs){
	function constructor(){
    for(var i=0;i<pairs.length;i++){
      if(expArgName.test(pairs[i].name)){
        eval("this." + pairs[i].name + "='" + pairs[i].value + "';");
      }
      else{
        log("Could not create arg property with name of '" + pairs[i].name + "'");
      }
    }
	}
  var a = this;
	var pairs = pairs == null?NA():pairs;
	var expArgName = /^[a-z_][\w]*$/i;
	constructor();
  a.add=function(nv){
      pairs.push(nv);
      if(expArgName.test(nv.name)){
        eval("this." + nv.name + "='" + nv.value + "';");
      }
      else{
        log("Could not create arg property with name of '" + nv.name + "'");
      }
  }
  a.convertStringArray=function(a){
      var o = NA();
      for(var i=0;i<a.length;i++){
          o[i] = new NameValuePair(a[i],a[i]);
      }
      return o;
  }
  a.addStringArray=function(a){
  	  var a = this.convertStringArray(a);
      for(var i=0;i<a.length;i++){
          this.add(a[i]);
      }
  }
  a.getAll = function(){
  	return pairs;
  }
  a.remove=function(x){
	  var index = -1;
	  var name = "";
	  if(typeof x == "number"){
	    index = x;
	    name = x < pairs.length?pairs[x].name:-1;
	  }
	  if(typeof x == "string"){
	    var name = x;
	    for(var i=0;i<pairs.length;i++){
	      if(pairs[i].name == x){
	        index = i;
	      }
	    }
	  }
	  if(index >=0 && index < pairs.length){
	    pairs.splice(index,1);
	    if(expArgName.test(name)){
	      eval("this." + name + " = null");
	    }
	  }
  }
  a.value=function(name){
    if(expArgName.test(name)){
      return eval("this." + name);
    }
    else{
      for(var i=0;i<pairs.length;i++){
        if(pairs[i].name == name) {return pairs[i].value;}
      }
    }
    return  null;
  }
	function clearPlusSigns(){
	  for(var i=0;i<pairs.length;i++){
	    pairs[i].value = pairs[i].value.replace(/\+/g," ");
	    if(expArgName.test(pairs[i].name)){
	      eval("this." + pairs[i].name + "='" + pairs[i].value + "';");
	    }
	  }
	}
	a.values = function(){
		var v = NA();
		for(var i=0;i<pairs.length;i++){
			v.push(pairs[i].value);
		}
		return v;
	}
	a.names = function(){
		var v = NA();
		for(var i=0;i<pairs.length;i++){
			v.push(pairs[i].name);
		}
		return v;
  }
}
NVPC = function(x){return new NameValuePairCollection(x)}
nvpc = NVPC();
function NVP(a,b){return new NameValuePair(a,b)}




