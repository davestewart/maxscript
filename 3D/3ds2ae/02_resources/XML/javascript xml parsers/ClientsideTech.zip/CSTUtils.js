/*  � Clientside Tech and NMG Consulting, LLC  (www.clientsidetech.com)  */
function NA(){return new Array()}
function ND(){return new Date()}
function IO(x,y){return x.indexOf(y)}
function SC(a,b){a.className = b}
function SV(a,b){a.value=b}
function SI(a,b){a.innerHTML=b}
function SD(a,b){a.style.display=b}
function TBD(a){TD(a,"block")}
function TID(a){TD(a,"inline")}
function TD(a,b){if(a.style.display=="none"){a.style.display=b}else{a.style.display="none"}}
