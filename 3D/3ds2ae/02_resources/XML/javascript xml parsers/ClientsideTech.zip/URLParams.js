/*  � Clientside Tech and NMG Consulting, LLC  (www.clientsidetech.com)  */
function getURLParams(){
  var x = document.location.href.split("?");
  var argStr = "";
  var args = NA();
  var pairs = NA();
  var argVals = NA();
  if(x.length > 1){
    argStr = x[1];
    argVals = argStr.split("&");
  }
  if(argVals.length > 0){
    for(var i=0;i<argVals.length;i++){
      pairs.push(new NameValuePair(unescape(argVals[i].split("=")[0]),unescape(argVals[i].split("=")[1])));
    }
  }
  return new NVPC(pairs);
}
window.PARAMS = getURLParams();

