SmartTabsManager = {
   
   tabs:NA(),
   add:function(x){
     this.tabs.push(x);
     this.tabs[x.id] = x;
   },
   init:function(){
      var x=this.tabs;
      for(var i=0;i<x.length;i++){
         x[i].init();
      }
   },
   makeTab:function(id,index){
      var x=stm.tabs;
	  var t = dc.gn(x[id].bVertical?"DIV":"SPAN",id+index,x[id].tabStyles[index],x[id].names[index]);
	  //var t = dc.gn("SPAN",id+index,x[id].tabStyles[index],x[id].names[index]);
      t.tabId=id;
      t.index=index;
      stm.setInactiveEvents(t);
	  return t;
   },
   setInactiveEvents:function(tab){ 
      if(stm.tabs[tab.tabId].bMouseover){
           tab.onmouseover=new Function("stm.setTab(this)");
      }
      else{
           tab.onmouseover=new Function("stm.applyTabStyle(this,'Hover')");
           tab.onmouseout=new Function("stm.applyTabStyle(this,'')");
           tab.onclick=new Function("stm.setTab(this)");
      }
   },
   setActiveEvents:function(tab){
           tab.onmouseover="";
           tab.onmouseout="";
           tab.onclick="";
   },
   setTab:function(tab){
       var I = tab.tabId;
       var x = tab.index
       var t = stm.getTabParent(tab);
       stm.hidePanes(tab);
       for(var i=0;i<t.names.length;i++){
           stm.applyTabStyle(t.tabs[i],"");
           stm.setInactiveEvents(t.tabs[i]);
       }
       stm.applyTabStyle(tab,"Active");
       if(!t.bMouseover) {
         stm.setActiveEvents(tab);
       }
       stm.showPane(t.panes[x]);
       stm.fireEvent(t.events[x]);
   },
   fireEvent:function(x){
     if(typeof x == "string"){
        eval(x);
     }
     else{
        x();
     }
   },
   applyTabStyle:function(tab,add){
       var t = stm.getTabParent(tab);
       SC(tab,t.tabStyles[tab.index]+add);
   },
   hidePanes:function(tab){
       var t = this.getTabParent(tab);
       for(var i=0;i<t.names.length;i++){
           SD(t.panes[i],"none");
       }
   },
   showPane:function(pane){
           SD(pane,"block");
   },
   getTabParent:function(tab){
      return this.tabs[tab.tabId];
   }
}
stm=SmartTabsManager;
function SmartTab(id,names,bVertical,bMouseover,styleRoot){
   var a=this;
   a.id=id;
   var styleRoot=styleRoot==null?"":styleRoot;
   a.names=names;
   a.tabs=NA();
   a.panes=NA();
   var tabsContainer;
   var panesContainer;
   a.tabStyles=NA();
   a.paneStyles=NA();
   var selectedTab=0;
   a.bVertical=bVertical==null?false:bVertical;
   a.bMouseover=bMouseover==null?false:bMouseover;
   a.events=NA();
   
   a.init = function(){
       tabsContainer = dh.b(a.id + "Tabs");
       panesContainer = dh.b(a.id + "Panes");
       var u = "undefined";
       for(var i=0;i<a.names.length;i++){
          if((typeof a.tabStyles[i])==u)a.tabStyles[i]=styleRoot+"Tab";
          if((typeof a.paneStyles[i])==u)a.paneStyles[i]=styleRoot+"Pane";
          if((typeof a.events[i])==u)a.events[i]=a.defaultEvent;
     
          dh.AC(tabsContainer,stm.makeTab(a.id,i));
          SC(dh.b(a.id+"Pane"+i),a.paneStyles[i]);          
          a.tabs.push(dh.b(a.id+i));        
          a.panes.push(dh.b(a.id+"Pane"+i));        
          SD(dh.b(a.id+"Pane"+i),"none");
       }
       SC(tabsContainer,a.id+"Tabs");
       SC(panesContainer,a.id+"Panes");
       stm.setTab(a.tabs[0]);
   }
   a.setTabStyle=function(style,tab){
           setValue(style,a.tabStyles,tab);
   }
   a.setPaneStyle=function(style,pane){
           setValue(style,a.paneStyles,pane);
   }
   a.setEvent=function(event,tab){
       setValue(event,a.events,tab);
   }

   function setValue(value,array,tab){
        var i = names.length;
        var j = i-1;
        if(tab == null){
            do{
                array[j--] = value;
             }while(--i);
        }
        else if(typeof tab == "string"){
            do{
                if(names[j] == tab) array[j] = value;
                j--;
            }while(--i);
        }
        else if (typeof tab == "number"){
            array[tab] = value;
        }
   }
   a.defaultEvent=function(){};

   stm.add(this);
}
