/*  � Clientside Tech and NMG Consulting, LLC  (www.clientsidetech.com)  */


/*
the following functions are automatically included as part of the Date object:

1.  getDayName()
Returns the name of the day of the week

2.  getMonthName()
Returns to the name of the month

3.  getAbbreviatedMonthName()
Returns the first three letters of the name of the month

4.  getDaysDifference(comparedDate)
returns the number of days apart from the comparedDate

5.  getMonthsDifference(comparedDate)
returns the number of months apart from the comparedDate

6.  getYearsDifference(comparedDate)
returns the number of years apart from the comparedDate

7. getCSTFormat()
returns the date string formatted as "m/dd/yyyy" 

8.  isBefore(comparedDate)
returns true of false if the date is earlier than the compared one

9.  isAfter(comparedDate)
returns true of false if the date is later than the compared one

10.  getOrdinalDate(){
returns the date of the month with the proper ordinal suffix (ie "21st", "3rd", etc)
}
*/



function getDayName()
{
    switch(this.getDay())
    {
        case 0:
            return 'Sunday';
        case 1:
            return 'Monday';
        case 2:
            return 'Tuesday';
        case 3:
            return 'Wednesday';
        case 4:
            return 'Thursday';
        case 5:
            return 'Friday';
        case 6:
            return 'Saturday';
    }
}
Date.prototype.getDayName=getDayName;

function getMonthName()
{
    switch(this.getMonth())
    {
        case 0:
            return 'January';
        case 1:
            return 'February';
        case 2:
            return 'March';
        case 3:
            return 'April';
        case 4:
            return 'May';
        case 5:
            return 'June';
        case 6:
            return 'July';
        case 7:
            return 'August';
        case 8:
            return 'September';
        case 9:
            return 'October';
        case 10:
            return 'November';
        case 11:
            return 'December';
    }
}
Date.prototype.getMonthName=getMonthName;
		  
function getAbbreviatedMonthName()
{
    switch(this.getMonth())
    {
        case 0:
            return 'Jan';
        case 1:
            return 'Feb';
        case 2:
            return 'Mar';
        case 3:
            return 'Apr';
        case 4:
            return 'May';
        case 5:
            return 'Jun';
        case 6:
            return 'Jul';
        case 7:
            return 'Aug';
        case 8:
            return 'Sep';
        case 9:
            return 'Oct';
        case 10:
            return 'Nov';
        case 11:
            return 'Dec';
    }
}
Date.prototype.getAbbreviatedMonthName=getAbbreviatedMonthName;

function getDaysDifference(xDate){
    return (xDate - this)/(60*60*24*1000);
}
Date.prototype.getDaysDifference = getDaysDifference;
		  
function getMonthsDifference(xDate){
    return (xDate - this)/( 60*60*24*1000*365/12);
}
Date.prototype.getMonthsDifference = getMonthsDifference;

function getYearsDifference(xDate){
    return (xDate - this)/( 60*60*24*1000*365);
}
Date.prototype.getYearsDifference = getYearsDifference;
		  
function toCSTFormat(){
   return (this.getMonth() + 1) + "/" + this.getDate() + "/" + this.getFullYear();
}		 
Date.prototype.toCSTFormat = toCSTFormat;

function isBefore(xDate){
   return xDate > this;
}
Date.prototype.isBefore = isBefore;

function isAfter(xDate){
   return xDate < this;
}
Date.prototype.isAfter = isAfter;
 
function getOrdinalDate(){
    var mDate = this.getDate();
	var suffix = "";
	if(mDate == 1 || mDate == 21 || mDate == 31){ suffix = "st"; }
	else if (mDate == 2 || mDate == 22){ suffix = "nd"; }
	else if(mDate == 3 || mDate == 23){suffix = "rd";}
	else{ suffix = "th";}
	return mDate + suffix;
}
Date.prototype.getOrdinalDate = getOrdinalDate; 


function getTimeStamp(){
  return this.getHours() + ":" + this.getMinutes() + ":" + this.getSeconds() + ":" + this.getMilliseconds();
}
Date.prototype.getTimeStamp = getTimeStamp; 